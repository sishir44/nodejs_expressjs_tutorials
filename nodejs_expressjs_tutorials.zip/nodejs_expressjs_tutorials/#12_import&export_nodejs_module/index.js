const { add, sub, mul, name } = require('./operator');
//console.log(add(5,5)); // func call (arguments)
console.log(add(5,5));
console.log(sub(9,5));
console.log(mul(10,5));
console.log(name);
