const fs = require('fs');

//create a file
fs.writeFileSync("bio.txt", 'My name is sishir !');
