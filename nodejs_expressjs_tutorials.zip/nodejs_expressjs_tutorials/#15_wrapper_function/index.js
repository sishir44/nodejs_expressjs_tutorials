// IIFE: Immediately Invoked Function Expression

( function(exports, require, module, _filename, _dirname) {
    const fs   = require("fs");
    const name = "sishir";
    console.log(name);
    module.exports = {}

})();
